#!/usr/bin/env python3
"""
release.py — hollywood release pipeline

Usage:
    ./release.py [rc]               # smoke-test + build source packages (default)
    ./release.py [rc] --interactive # same, but prompt for confirmation at each step
    ./release.py final              # cut a full release: tag, GitHub release, upload
    ./release.py open-dev           # bump debian/changelog and open next cycle
    ./release.py salsa-ci           # local Docker gbp buildpackage dry-run

RC phases (run all in parallel after preflight):
    1   Pre-flight checks
    2   Determine versions
    3   Smoke test (Docker ubuntu:noble — build, install, verify)  ┐ parallel
    3b  Salsa CI dry-run  (Docker debian:sid — gbp buildpackage)   ┘
    4   PPA source builds (Docker ubuntu:noble, one container per series)
    5   Debian source build (Docker ubuntu:noble)

Final skips phase 3 (smoke already passed on RC commit):
    6   Git tag + GitHub release
    7   Sign and upload (GPG sign + dput — interactive)
    8   Salsa push (push tag + HEAD to salsa games-team)
    9   Chainguard reminder
    10  Open next development cycle (open-dev) — confirmed, auto-proceeds
        by default (same as byobu's release.py); `-i` lets you skip it
        for this run with 's'. Leaves the next cycle with a home from
        the moment `final` exits, instead of post-release commits
        silently piling onto the version that was just shipped.
"""

import argparse
import concurrent.futures
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

HOLLYWOOD_SRC = Path(__file__).resolve().parent.parent

# Launchpad PPA target — change if Hollywood gets its own PPA.
PPA_TARGET = "ppa:hollywood/ppa"

# Salsa remote name — add with:
#   git remote add salsa git@salsa.debian.org:games-team/hollywood.git
SALSA_REMOTE = "salsa"
SALSA_BRANCH = "master"
SALSA_UPSTREAM_BRANCH = "upstream"


# ── thread-local stdout (parallel output capture) ──────────────────────────

_tls = threading.local()


class _TLSStdout:
    def __init__(self, real):
        self._real = real

    def _buf(self):
        return getattr(_tls, "buf", None)

    def write(self, s):
        b = self._buf()
        (b if b is not None else self._real).write(s)

    def flush(self):
        if self._buf() is None:
            self._real.flush()

    def isatty(self):
        return False if self._buf() is not None else self._real.isatty()

    def fileno(self):
        return self._real.fileno()


sys.stdout = _TLSStdout(sys.stdout)


# ── helpers ────────────────────────────────────────────────────────────────

def run(cmd, check=True, capture=False, **kwargs):
    kw = dict(text=True, **kwargs)
    if capture:
        kw.update(stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return subprocess.run(cmd, shell=isinstance(cmd, str), check=check, **kw)
    buf = getattr(_tls, "buf", None)
    if buf is not None:
        kw.update(stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        # check=False here regardless of the caller's check: subprocess.run's
        # own check=True raises from inside the call, before this function
        # ever reaches the buf.write() below -- silently discarding exactly
        # the output a failure needs to be diagnosable. Do the check
        # ourselves, after capturing.
        result = subprocess.run(cmd, shell=isinstance(cmd, str), check=False, **kw)
        buf.write(result.stdout or "")
        if check and result.returncode != 0:
            short = (cmd[0] if isinstance(cmd, list) else str(cmd).split()[0])
            buf.write(f"\n[exit {result.returncode}] {short}\n")
            raise subprocess.CalledProcessError(result.returncode, cmd, result.stdout)
        return result
    return subprocess.run(cmd, shell=isinstance(cmd, str), check=check, **kw)


def run_parallel(labeled_fns, log_dir=None):
    if not labeled_fns:
        return
    if len(labeled_fns) == 1:
        labeled_fns[0][1]()
        return

    labels = [l for l, _ in labeled_fns]
    print(f"\n  ⟳ Launching in parallel: {', '.join(labels)}")
    outcomes = {}

    def _run_one(label, fn):
        buf = io.StringIO()
        _tls.buf = buf
        try:
            fn()
            outcomes[label] = (buf.getvalue(), None)
        except BaseException as exc:
            outcomes[label] = (buf.getvalue(), exc)
        finally:
            _tls.buf = None

    threads = [threading.Thread(target=_run_one, args=(l, f)) for l, f in labeled_fns]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    any_failed = False
    for label in labels:
        out, exc = outcomes.get(label, ("", RuntimeError("phase did not run")))
        marker = "✓" if exc is None else "✗"
        print(f"\n── {marker} {label} " + "─" * max(0, 55 - len(label)))
        for line in out.rstrip().splitlines():
            print(f"  {line}")
        if exc is not None:
            print(f"  ✗ {label}: {exc}")
            any_failed = True
            if log_dir:
                slug = label.replace(" ", "-")
                log_path = Path(log_dir) / f"{slug}.log"
                log_path.write_text(out + f"\n--- FAILED: {exc}\n")
                print(f"  (full log: {log_path})")
    if any_failed:
        die("One or more parallel phases failed (see output above).")


def die(msg):
    print(f"\n✗  {msg}", file=sys.stderr)
    sys.exit(1)


# Canonical phase order for --start-from (ported from byobu's release.py):
# resume a `final` run that died partway through without re-running (and
# re-wiping the output of) everything before it.
_PHASE_ORDER = ["3", "4", "5", "6", "7", "8", "9"]


def should_run(phase, start_from):
    if start_from is None:
        return True
    return _PHASE_ORDER.index(phase) >= _PHASE_ORDER.index(start_from)


_interactive = False


def confirm(prompt, skippable=False, always=False):
    """Prompt to proceed/skip/abort.

    Non-interactive mode (the default — no -i/--interactive) auto-proceeds
    without prompting, UNLESS always=True. always=True is for the steps
    that put the maintainer's signature on artifacts and publish them
    (GPG signing, PPA/mentors upload, GitHub release, Salsa push) — those
    must never happen without a human reading what is about to be signed
    and published, regardless of --interactive, and refuse outright if
    stdin isn't a real terminal to confirm from.
    """
    if not _interactive and not always:
        print(f"\n  (auto-proceeding: {prompt[:70]}{'…' if len(prompt) > 70 else ''})")
        return True
    if always and not sys.stdin.isatty():
        die("This step needs an explicit yes from a terminal and stdin is not one.\n"
            "  Re-run from an interactive shell (or with -i).")
    opts = "[y/s/N]" if skippable else "[y/N]"
    ans = input(f"\n{prompt} {opts} ").strip().lower()
    if ans in ("y", "yes"):
        return True
    if skippable and ans in ("s", "skip"):
        print("  (skipped)")
        return False
    die("Aborted.")


def banner(msg):
    w = 62
    print(f"\n{'━' * w}\n  {msg}\n{'━' * w}")


def section(msg):
    print(f"\n── {msg} " + "─" * max(0, 58 - len(msg)))


# ── phase 1: pre-flight ────────────────────────────────────────────────────

def load_identity():
    section("Phase 1: Pre-flight checks")
    bashrc = Path("~/.bashrc").expanduser().read_text()

    def extract(key):
        m = re.search(rf"export {key}=['\"]?([^'\"#\n]+)['\"]?", bashrc)
        return m.group(1).strip() if m else ""

    identity = {
        "DEBEMAIL":    extract("DEBEMAIL"),
        "DEBFULLNAME": extract("DEBFULLNAME"),
        "GPGKEY":      extract("GPGKEY"),
    }
    for k, v in identity.items():
        print(f"  {k}={v}")

    if not all(identity.values()):
        die(
            "Missing identity in ~/.bashrc. Add:\n"
            "  export DEBFULLNAME='Dustin Kirkland'\n"
            "  export DEBEMAIL='kirkland@ubuntu.com'\n"
            "  export GPGKEY='<your GPG key fingerprint>'"
        )
    return identity


def check_tools(mode):
    required = ["dput", "debsign", "git", "docker", "gh"]
    if mode == "final":
        required.append("gbp")
    missing = [t for t in required if not shutil.which(t)]
    if missing:
        die(
            f"Missing tools: {' '.join(missing)}\n"
            "  sudo apt install devscripts dput git-buildpackage gh"
        )
    print(f"  Tools OK: {' '.join(required)}")



def check_clean():
    r = run(["git", "-C", str(HOLLYWOOD_SRC), "status", "--porcelain"], capture=True)
    if r.stdout.strip():
        die(
            "Working tree has uncommitted changes:\n"
            + r.stdout
            + "\n  Commit or stash before releasing."
        )
    print("  Working tree clean.")


def check_salsa_sync(mode):
    r = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "remote", "get-url", SALSA_REMOTE],
        capture=True, check=False,
    )
    if r.returncode != 0:
        return  # no salsa remote

    run(["git", "-C", str(HOLLYWOOD_SRC), "fetch", SALSA_REMOTE], check=False)

    salsa_ref = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "rev-parse",
         f"{SALSA_REMOTE}/{SALSA_BRANCH}"],
        capture=True, check=False,
    )
    if salsa_ref.returncode != 0:
        return  # salsa branch not yet created

    merge_base = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "merge-base",
         "HEAD", f"{SALSA_REMOTE}/{SALSA_BRANCH}"],
        capture=True, check=False,
    )
    if (merge_base.returncode == 0 and
            merge_base.stdout.strip() != salsa_ref.stdout.strip()):
        msg = (
            f"salsa/{SALSA_BRANCH} has commits not in local master.\n"
            f"  Merge first: git fetch salsa && git merge salsa/{SALSA_BRANCH}\n"
            f"  Then re-run."
        )
        if mode == "final":
            die(msg)
        else:
            print(f"  WARNING: {msg}")
    else:
        print(f"  \u2713 salsa/{SALSA_BRANCH} in sync")


def prewarm_gpg(identity):
    import tempfile
    section("Phase 1b: GPG pre-warm")
    gpgkey = identity["GPGKEY"]
    print(f"  Key: {gpgkey}")
    print("  Enter passphrase now — gpg-agent will serve it automatically in phase 7.")
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
        f.write(b"hollywood release gpg pre-warm\n")
        tmpfile = Path(f.name)
    sig = Path(str(tmpfile) + ".asc")
    try:
        run(["gpg", "--armor", "--detach-sign", "-u", gpgkey,
             "--output", str(sig), str(tmpfile)])
        print("  ✓ GPG agent unlocked.")
    finally:
        tmpfile.unlink(missing_ok=True)
        sig.unlink(missing_ok=True)


# ── phase 2: versions ─────────────────────────────────────────────────────

def ubuntu_series():
    """Return (supported, devel, devel_status) Ubuntu series names.

    Launchpad is authoritative: the host's distro-info-data lags behind each
    Ubuntu release (ported from byobu's release.py — see its 0f2be23f: on
    26.10's release week the host still listed the previous series as
    newest and `ubuntu-distro-info --devel` failed, and the old hardcoded
    fallback here ("oracular") would then have pointed a build at a
    released series too, same failure shape). ubuntu-distro-info is only a
    fallback for when Launchpad is unreachable, and must then actually
    know a devel series (--devel fails when stale). supported excludes the
    devel series; it's what the PPA builds for.
    """
    try:
        def lp(url):
            return json.loads(urllib.request.urlopen(url, timeout=30).read())
        devel = lp("https://api.launchpad.net/1.0/ubuntu")["current_series_link"].rsplit("/", 1)[1]
        entries = lp("https://api.launchpad.net/1.0/ubuntu/series")["entries"]
        status = {e["name"]: e["status"] for e in entries}
        supported = [
            e["name"]
            for e in sorted(entries, key=lambda e: float(e.get("version") or "0"))
            if e["status"] in ("Current Stable Release", "Supported")
            and float(e.get("version") or "0") >= 22.04
        ]
        if devel not in status or devel in supported or not supported:
            raise RuntimeError(f"implausible Launchpad series data: devel={devel}")
        return supported, devel, status[devel]
    except Exception as e:
        print(f"  (Launchpad series query failed: {e} — falling back to ubuntu-distro-info)")
    try:
        supported = run(["ubuntu-distro-info", "--supported"], capture=True).stdout.split()
        devel = run(["ubuntu-distro-info", "--devel"], capture=True, check=False).stdout.strip()
    except (FileNotFoundError, subprocess.CalledProcessError):
        supported, devel = [], ""
    if not devel:
        die("Could not determine the Ubuntu development series: Launchpad is unreachable\n"
            "  and ubuntu-distro-info has no devel series (update distro-info-data).")
    supported = [s for s in supported if s != devel]
    return supported, devel, "unknown (from distro-info)"


def determine_versions(mode, resume=False):
    section("Phase 2: Determine versions")

    cl = (HOLLYWOOD_SRC / "debian" / "changelog").read_text()
    m = re.search(r"^hollywood \(([^)]+)\)", cl)
    if not m:
        die("Cannot parse version from debian/changelog")

    raw_ver = m.group(1).strip()
    # Strip Debian revision (-N) to get the upstream version
    base_ver = re.sub(r"-\d+$", "", raw_ver)
    print(f"  changelog version: {raw_ver}  →  upstream: {base_ver}")

    deb_version   = f"{base_ver}-1"
    ubuntu_ver    = f"{base_ver}-0ubuntu1"

    series, devel_series, devel_status = ubuntu_series()

    print(f"  Debian:       {deb_version}")
    print(f"  Ubuntu:       {ubuntu_ver} → {devel_series}  ({devel_status})")
    print(f"  PPA series:   {' '.join(series)}")
    if mode == "final" and devel_status != "Active Development":
        print(f"  ⚠ {devel_series} is in '{devel_status}', not 'Active Development';\n"
              f"    an upload may sit in the unapproved queue until the archive opens.")

    outdir = Path(f"/tmp/hollywood-release-{base_ver}")
    if resume:
        # --start-from: reuse whatever earlier phases already built (PPA
        # .changes/.dsc, the Debian source package, ...) instead of wiping
        # it -- that's the whole point of resuming rather than restarting.
        if not outdir.exists():
            die(f"--start-from: output directory {outdir} not found.\n"
                f"  Run without --start-from first to (re)create it.")
        for sub in ["debs", "debian", "ppa", "ubuntu", "logs"]:
            (outdir / sub).mkdir(parents=True, exist_ok=True)
        print(f"  Resuming in: {outdir}")
    else:
        if outdir.exists():
            shutil.rmtree(outdir)
        for sub in ["debs", "debian", "ppa", "ubuntu", "logs"]:
            (outdir / sub).mkdir(parents=True)
        print(f"  Output dir:   {outdir}")

    return dict(
        base_ver=base_ver,
        deb_version=deb_version,
        ubuntu_ver=ubuntu_ver,
        series=series,
        devel_series=devel_series,
        outdir=outdir,
    )


# ── phase 3: smoke test ───────────────────────────────────────────────────

_SMOKE_SCRIPT = r"""
set -e
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y --no-install-recommends \
  build-essential dpkg-dev debhelper devscripts \
  tmux byobu 2>&1 | tail -5

WORKDIR=$(mktemp -d)
cp -a /src "$WORKDIR/hollywood"
cd "$WORKDIR/hollywood"

echo "--- Build ---"
dpkg-buildpackage -us -uc -b 2>&1 | tail -5

echo "--- Install ---"
apt-get install -y "$WORKDIR"/*.deb 2>&1 | tail -5

echo "--- Verify files ---"
test -x /usr/games/hollywood  && echo "  ✓ /usr/games/hollywood"
test -x /usr/games/wallstreet && echo "  ✓ /usr/games/wallstreet"
test -d /usr/lib/hollywood    && echo "  ✓ /usr/lib/hollywood"
# Checked against the built .deb's own contents, not the installed
# filesystem: Ubuntu's official Docker images path-exclude
# /usr/share/man/* at the dpkg level (see /etc/dpkg/dpkg.cfg.d/docker),
# so the man page never actually lands on disk here even though the
# package correctly contains it -- that's a Docker-image policy, not
# a packaging bug, so verify the package instead of the filesystem.
dpkg-deb -c "$WORKDIR"/hollywood_*.deb | grep -q '/usr/share/man/man1/hollywood\.1\.gz$' \
  && echo "  ✓ man page (in .deb)"

NWIDGETS=$(ls /usr/lib/hollywood/ | wc -l)
echo "  ✓ $NWIDGETS widgets installed"

echo "--- Widget shebang + executable check ---"
for w in /usr/lib/hollywood/*; do
  test -x "$w" || { echo "  ✗ NOT executable: $w"; exit 1; }
  head -1 "$w" | grep -q "^#!" || { echo "  ✗ Missing shebang: $w"; exit 1; }
done
echo "  ✓ All widgets OK"

echo "=== Smoke test PASSED ==="
"""


def run_smoke_test():
    section("Phase 3: Smoke test (Docker ubuntu:noble)")
    run([
        "docker", "run", "--rm",
        "-v", f"{HOLLYWOOD_SRC}:/src:ro",
        "ubuntu:noble", "bash", "-c", _SMOKE_SCRIPT,
    ])
    print("  ✓ Smoke test PASSED")


# ── phase 3b: Salsa CI dry-run ────────────────────────────────────────────

_SALSA_CI_SCRIPT = r"""
set -eo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y --no-install-recommends \
  git git-buildpackage debhelper devscripts lintian 2>&1 | tail -5

git config --global --add safe.directory '*'
git clone /src /build/hollywood
cd /build/hollywood

git checkout -b debian/latest
git config user.email "ci@salsa.local"
git config user.name "Salsa CI"
git add -f debian/
# debian/ already lives on the same branch as everything else in this
# repo (no separate upstream-only branch to layer packaging onto), so
# this is a no-op here and `git commit` would fail on "nothing to
# commit" -- which, under set -e, kills the whole phase. Only commit
# if there's actually something staged.
git diff --cached --quiet || git commit -q -m "debian: add packaging (Salsa CI simulation)"

echo "--- gbp buildpackage ---"
gbp buildpackage \
  --git-export-dir=/tmp/build-area \
  --git-no-sign-tags \
  --git-ignore-branch \
  -us -uc -d -sa 2>&1 | tail -10

ls -lh /tmp/build-area/
echo "=== Salsa CI PASSED ==="
"""


def run_salsa_ci():
    section("Phase 3b / salsa-ci: gbp buildpackage (Docker debian:sid)")
    run([
        "docker", "run", "--rm",
        "-v", f"{HOLLYWOOD_SRC}:/src:ro",
        "debian:sid", "bash", "-c", _SALSA_CI_SCRIPT,
    ])
    print("  ✓ Salsa CI simulation PASSED")


# ── phase 4: PPA source builds ────────────────────────────────────────────

_PPA_SERIES_SCRIPT = r"""
set -eo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y --no-install-recommends \
  build-essential dpkg-dev debhelper devscripts git 2>&1 | tail -5

git config --global --add safe.directory /src

SRCDIR=$(mktemp -d)
git -C /src archive --format=tar HEAD | tar -x -C "$SRCDIR"

PPA_VER="${BASE_VER}~${CODENAME}1"
echo "=== Building $PPA_VER ==="

BUILDDIR=$(mktemp -d)
cp -a "$SRCDIR" "$BUILDDIR/${PKG}-${PPA_VER}"
cp -a /src/debian "$BUILDDIR/${PKG}-${PPA_VER}/"
cd "$BUILDDIR/${PKG}-${PPA_VER}"

echo "3.0 (native)" > debian/source/format

DATESTAMP=$(date -R)
{
  printf "%s (%s) %s; urgency=medium\n\n" "$PKG" "$PPA_VER" "$CODENAME"
  printf "  * PPA build %s\n\n" "$PPA_VER"
  printf " -- %s <%s>  %s\n\n" "$DEBFULLNAME" "$DEBEMAIL" "$DATESTAMP"
  cat debian/changelog
} > debian/changelog.new
mv debian/changelog.new debian/changelog

dpkg-buildpackage -S -us -uc -d 2>&1 | tail -3

cp -v "$BUILDDIR"/*.changes "$BUILDDIR"/*.dsc \
      "$BUILDDIR"/*.tar.* "$BUILDDIR"/*.buildinfo /out/ 2>/dev/null || true
chown -R $(stat -c '%u:%g' /out) /out/
echo "=== $CODENAME done ==="
"""


def build_ppa_packages(v, identity):
    section("Phase 4: PPA source builds (parallel, all series)")
    ppa_series = [s for s in v["series"] if s != v["devel_series"]]
    print(f"  Series ({len(ppa_series)}): {' '.join(ppa_series)}")

    errors = {}

    def _build_one(codename):
        buf = io.StringIO()
        prev = getattr(_tls, "buf", None)
        _tls.buf = buf
        try:
            run([
                "docker", "run", "--rm",
                "-v", f"{HOLLYWOOD_SRC}:/src:ro",
                "-v", f"{v['outdir']}/ppa:/out",
                "-e", f"DEBEMAIL={identity['DEBEMAIL']}",
                "-e", f"DEBFULLNAME={identity['DEBFULLNAME']}",
                "-e", "PKG=hollywood",
                "-e", f"BASE_VER={v['base_ver']}",
                "-e", f"CODENAME={codename}",
                "ubuntu:noble", "bash", "-c", _PPA_SERIES_SCRIPT,
            ])
        except Exception as exc:
            errors[codename] = exc
        finally:
            _tls.buf = prev

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ppa_series)) as ex:
        futures = [ex.submit(_build_one, s) for s in ppa_series]
        concurrent.futures.wait(futures)

    for codename in ppa_series:
        marker = "✗" if codename in errors else "✓"
        print(f"  {marker} {codename}" + (f": {errors[codename]}" if codename in errors else ""))

    if errors:
        die(f"PPA build failed for: {', '.join(errors)}")

    changes = sorted((v["outdir"] / "ppa").glob("*.changes"))
    print(f"  ✓ PPA source packages built ({len(changes)} series)")
    for f in changes:
        print(f"    {f.name}")


# ── phase 5: Debian source build ─────────────────────────────────────────

_DEB_SOURCE_SCRIPT = r"""
set -eo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y --no-install-recommends \
  build-essential dpkg-dev debhelper devscripts git 2>&1 | tail -5

git config --global --add safe.directory /src

BUILDDIR=$(mktemp -d)

git -C /src archive --format=tar.gz --prefix="hollywood-${BASE_VER}/" HEAD \
  -o "$BUILDDIR/hollywood_${BASE_VER}.orig.tar.gz"

mkdir "$BUILDDIR/hollywood-${BASE_VER}"
tar -xzf "$BUILDDIR/hollywood_${BASE_VER}.orig.tar.gz" \
    -C "$BUILDDIR/hollywood-${BASE_VER}" --strip-components=1
cp -a /src/debian "$BUILDDIR/hollywood-${BASE_VER}/"

cd "$BUILDDIR/hollywood-${BASE_VER}"
echo "3.0 (quilt)" > debian/source/format

sed -i "1s/^hollywood ([^)]*)/hollywood (${DEB_VERSION})/" debian/changelog
sed -i "1s/) [^;]*;/) unstable;/" debian/changelog

dpkg-buildpackage -S -us -uc -d -sa 2>&1 | tail -3

cp -v "$BUILDDIR"/*.changes "$BUILDDIR"/*.dsc \
      "$BUILDDIR"/*.tar.* "$BUILDDIR"/*.buildinfo /out/ 2>/dev/null || true
chown -R $(stat -c '%u:%g' /out) /out/
echo "=== Debian unstable source built ==="
ls -lh /out/
"""


def build_debian_source(v, identity):
    section("Phase 5: Debian unstable source build (Docker)")
    run([
        "docker", "run", "--rm",
        "-v", f"{HOLLYWOOD_SRC}:/src:ro",
        "-v", f"{v['outdir']}/debian:/out",
        "-e", f"DEBEMAIL={identity['DEBEMAIL']}",
        "-e", f"DEBFULLNAME={identity['DEBFULLNAME']}",
        "-e", f"BASE_VER={v['base_ver']}",
        "-e", f"DEB_VERSION={v['deb_version']}",
        "ubuntu:noble", "bash", "-c", _DEB_SOURCE_SCRIPT,
    ])
    changes = sorted((v["outdir"] / "debian").glob("*.changes"))
    if not changes:
        die(f"Debian build produced no .changes files in {v['outdir']}/debian/")
    print(f"  ✓ Debian source package built")
    for f in changes:
        print(f"    {f.name}")


# ── phase 6: git tag + GitHub release ────────────────────────────────────

def create_github_release(v, identity):
    section("Phase 6: Git tag + GitHub release")
    tag = v["base_ver"]

    # Not skippable: push_salsa()'s gbp import-orig later archives this tag,
    # so skipping here would just fail downstream instead of up front.
    confirm(f"Create signed tag {tag}, push it to origin, and publish a "
            f"GitHub release?", always=True)

    local = run(["git", "-C", str(HOLLYWOOD_SRC), "tag", "--list", tag], capture=True)
    if tag in local.stdout.split():
        print(f"  (tag {tag} already exists locally — skipping creation)")
    else:
        # -u (not just -s): user.signingkey is unset, and there are multiple
        # secret keys in the keyring with overlapping "Dustin Kirkland" UIDs
        # (gpg --list-secret-keys), so a bare -s leaves GPG to pick whichever
        # it defaults to -- not necessarily identity["GPGKEY"], the one every
        # other signing step here (debsign, prewarm_gpg) explicitly uses.
        run(["git", "-C", str(HOLLYWOOD_SRC), "tag", "-u", identity["GPGKEY"],
             tag, "-m", f"hollywood {tag}"])
        print(f"  ✓ Tag {tag} created (signed with {identity['GPGKEY']})")

    remote = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "ls-remote", "--tags", "origin", tag],
        capture=True,
    )
    if remote.stdout.strip():
        print(f"  (tag {tag} already on origin — skipping push)")
    else:
        run(["git", "-C", str(HOLLYWOOD_SRC), "push", "origin", tag])
        print(f"  ✓ Tag {tag} pushed to origin")

    result = run(
        ["gh", "release", "view", tag, "--repo", "dustinkirkland/hollywood"],
        check=False, capture=True,
    )
    if result.returncode == 0:
        print(f"  (GitHub release {tag} already exists — skipping)")
    else:
        run([
            "gh", "release", "create", tag,
            "--repo", "dustinkirkland/hollywood",
            "--title", f"hollywood {tag}",
            "--generate-notes",
        ])
        print(f"  ✓ GitHub release {tag} created")


# ── phase 7: sign and upload ─────────────────────────────────────────────

def sign_and_upload(v, identity):
    section("Phase 7: Sign and upload")
    gpgkey = identity["GPGKEY"]
    outdir = v["outdir"]

    print(f"\n── Step 1: GPG signing  (key: {gpgkey})")
    to_sign = [
        f for subdir in ["ppa", "debian"]
        for f in sorted((outdir / subdir).glob("*_source.changes"))
    ]
    print(f"  {len(to_sign)} file(s) to sign:")
    for f in to_sign:
        print(f"    {f.name}")
    confirm(f"  Sign {len(to_sign)} file(s) with GPG key {gpgkey}?", always=True)
    signed = 0
    for f in to_sign:
        print(f"  Signing: {f.name}")
        run(["debsign", "-k", gpgkey, str(f)])
        signed += 1
    print(f"  ✓ {signed} file(s) signed.")

    print(f"\n── Step 2: PPA  {PPA_TARGET}")
    if confirm(f"  Upload all series to {PPA_TARGET}?", skippable=True, always=True):
        for f in sorted((outdir / "ppa").glob("*_source.changes")):
            print(f"  dput {PPA_TARGET} {f.name}")
            run(["dput", PPA_TARGET, str(f)])
        print(f"  ✓ PPA uploads done.")
        print(f"    Monitor: https://launchpad.net/~hollywood/+archive/ubuntu/ppa")

    print("\n── Step 3: Debian unstable  (mentors.debian.net)")
    deb_changes = sorted((outdir / "debian").glob("*_source.changes"))
    if deb_changes:
        if confirm("  Upload to mentors.debian.net?", skippable=True, always=True):
            run(["dput", "mentors", str(deb_changes[0])])
            print(f"\n  ✓ Uploaded. Email Andreas Tille <tille@debian.org>:")
            print(f"    Subject: hollywood {v['deb_version']} sponsorship request")
            print(f"    Body:    https://mentors.debian.net/package/hollywood")
    else:
        print("  (no .changes files found — skipping)")

    print("\n  ✓ Sign and upload complete.")


# ── phase 8: Salsa push ───────────────────────────────────────────────────

def push_salsa(v):
    section("Phase 8: Push to Debian Salsa (games-team)")
    tag = v["base_ver"]

    r = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "remote", "get-url", SALSA_REMOTE],
        capture=True, check=False,
    )
    if r.returncode != 0:
        print(
            f"  Salsa remote '{SALSA_REMOTE}' not configured. Add it with:\n"
            f"    git remote add {SALSA_REMOTE} "
            f"git@salsa.debian.org:games-team/hollywood.git\n"
            f"  Skipping Salsa push."
        )
        return

    if not confirm(f"Push master + tag {tag} to salsa/{SALSA_BRANCH}, and seed the "
                    f"upstream branch there (gbp import-orig)?", skippable=True, always=True):
        print("  (Salsa push skipped)")
        return

    print("  Fetching salsa to check for upstream commits…")
    run(["git", "-C", str(HOLLYWOOD_SRC), "fetch", SALSA_REMOTE])

    salsa_ref = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "rev-parse",
         f"{SALSA_REMOTE}/{SALSA_BRANCH}"],
        capture=True, check=False,
    )
    if salsa_ref.returncode == 0:
        merge_base = run(
            ["git", "-C", str(HOLLYWOOD_SRC), "merge-base",
             "HEAD", f"{SALSA_REMOTE}/{SALSA_BRANCH}"],
            capture=True, check=False,
        )
        if (merge_base.returncode == 0 and
                merge_base.stdout.strip() != salsa_ref.stdout.strip()):
            die(
                f"salsa/{SALSA_BRANCH} has commits not in local master.\n"
                f"  Merge first: git merge {SALSA_REMOTE}/{SALSA_BRANCH}\n"
                f"  Then re-run."
            )

    run(["git", "-C", str(HOLLYWOOD_SRC), "push", SALSA_REMOTE,
         f"HEAD:refs/heads/{SALSA_BRANCH}"])
    print(f"  ✓ salsa/{SALSA_BRANCH} updated")

    remote_tag = run(
        ["git", "-C", str(HOLLYWOOD_SRC), "ls-remote", "--tags", SALSA_REMOTE, tag],
        capture=True,
    )
    if remote_tag.stdout.strip():
        print(f"  (tag {tag} already on salsa — skipping)")
    else:
        run(["git", "-C", str(HOLLYWOOD_SRC), "push", SALSA_REMOTE, tag])
        print(f"  ✓ Tag {tag} pushed to salsa")

    print(f"    https://salsa.debian.org/games-team/hollywood")

    # Phase 8b: seed upstream branch via gbp import-orig
    section("Phase 8b: Seed upstream branch (gbp import-orig)")
    import tempfile
    with tempfile.TemporaryDirectory(prefix="hollywood-salsa-") as tmpdir_s:
        tmpdir = Path(tmpdir_s)
        orig_name = f"hollywood_{tag}.orig.tar.gz"
        orig_path = tmpdir / orig_name

        print(f"  Generating {orig_name} from tag {tag}\u2026")
        run(["git", "-C", str(HOLLYWOOD_SRC), "archive",
             "--format=tar.gz", f"--prefix=hollywood-{tag}/",
             f"--output={orig_path}", tag])

        salsa_clone = tmpdir / "hollywood-salsa"
        print("  Cloning Salsa into temp dir\u2026")
        run(["git", "clone",
             "git@salsa.debian.org:games-team/hollywood.git",
             str(salsa_clone)])

        run(["git", "-C", str(salsa_clone), "config",
             "user.email", "dustin.kirkland@gmail.com"])
        run(["git", "-C", str(salsa_clone), "config",
             "user.name", "Dustin Kirkland"])

        # A plain clone only checks out a local branch for HEAD (master);
        # SALSA_UPSTREAM_BRANCH exists on the remote but only as
        # origin/upstream until a local branch is made for it, and
        # `gbp import-orig --upstream-branch=upstream` requires the local
        # branch to already exist ("Repository does not have branch
        # 'upstream'") -- it won't create it for you.
        run(["git", "-C", str(salsa_clone), "branch", SALSA_UPSTREAM_BRANCH,
             f"origin/{SALSA_UPSTREAM_BRANCH}"])

        print("  Running gbp import-orig\u2026")
        # --no-interactive + an explicit --upstream-version: without them
        # gbp prompts ("What is the upstream version? [1.26]") and dies on
        # EOF the moment stdin isn't a terminal -- it already guesses the
        # right default, it just won't act on a guess without asking.
        run(["gbp", "import-orig",
             f"--upstream-branch={SALSA_UPSTREAM_BRANCH}",
             f"--debian-branch={SALSA_BRANCH}",
             f"--upstream-version={v['base_ver']}",
             "--no-interactive",
             "--no-merge",
             str(orig_path)],
            cwd=str(salsa_clone))

        print(f"  Pushing {SALSA_UPSTREAM_BRANCH} to Salsa\u2026")
        run(["git", "-C", str(salsa_clone), "push", "origin",
             SALSA_UPSTREAM_BRANCH])
        print(f"  \u2713 upstream branch seeded on Salsa")


# ── phase 9: Chainguard reminder ─────────────────────────────────────────

def chainguard_reminder(v):
    section("Phase 9: Chainguard")
    print(
        f"\n  The cgr.dev/chainguard/hollywood image is built from the Chainguard\n"
        f"  images repository. After the Debian upload is accepted, verify that\n"
        f"  the image has picked up hollywood {v['base_ver']}:\n"
        f"\n"
        f"    docker run --rm cgr.dev/chainguard/hollywood --version 2>/dev/null || \\\n"
        f"      docker run --rm cgr.dev/chainguard/hollywood\n"
        f"\n"
        f"  If the image has not updated within a few days of the Debian upload,\n"
        f"  file an issue or PR at:\n"
        f"    https://github.com/chainguard-images/images\n"
        f"  and reference the Debian tracker:\n"
        f"    https://tracker.debian.org/pkg/hollywood\n"
    )


# ── open-dev ──────────────────────────────────────────────────────────────

def open_dev(identity):
    banner("open-dev: bump to next development version")

    cl_path = HOLLYWOOD_SRC / "debian" / "changelog"
    cl = cl_path.read_text()
    m = re.search(r"^hollywood \(([^)]+)\)", cl)
    if not m:
        die("Cannot parse version from debian/changelog")
    raw_ver = m.group(1).strip()
    base_ver = re.sub(r"-\d+$", "", raw_ver)

    parts = base_ver.rsplit(".", 1)
    try:
        next_ver = f"{parts[0]}.{int(parts[1]) + 1}"
    except (IndexError, ValueError):
        die(f"Cannot auto-increment version '{base_ver}' — edit debian/changelog manually.")

    print(f"  {base_ver}  →  {next_ver}")

    datestamp = subprocess.check_output(["date", "-R"]).decode().strip()
    new_stanza = (
        f"hollywood ({next_ver}-1) UNRELEASED; urgency=medium\n"
        f"\n"
        f"  * Open {next_ver} for development\n"
        f"\n"
        f" -- {identity['DEBFULLNAME']} <{identity['DEBEMAIL']}>  {datestamp}\n"
        f"\n"
    )
    cl_path.write_text(new_stanza + cl)
    print("\n  debian/changelog top:")
    for line in cl_path.read_text().splitlines()[:5]:
        print(f"    {line}")

    run(["git", "-C", str(HOLLYWOOD_SRC), "add", "debian/changelog"])
    run(["git", "-C", str(HOLLYWOOD_SRC), "commit",
         "-m", f"bump version to {next_ver} and open for development"])
    print(f"  ✓ Committed: bump version to {next_ver}")


# ── summary ───────────────────────────────────────────────────────────────

def print_summary(v, mode):
    outdir = v["outdir"]
    label = "RC build" if mode == "rc" else "Release"
    banner(f"{label} complete: hollywood {v['base_ver']}")
    print(
        f"\n  PPA:     {PPA_TARGET} — {v['base_ver']}~{{series}}1\n"
        f"  Debian:  hollywood {v['deb_version']} → unstable\n"
        f"  Chainguard: check cgr.dev/chainguard/hollywood after Debian accept\n"
    )
    if mode == "final":
        print(
            f"  GitHub:  https://github.com/dustinkirkland/hollywood/releases/tag/{v['base_ver']}\n"
            f"  Salsa:   https://salsa.debian.org/games-team/hollywood\n"
        )
    print(f"  Artifacts: {outdir}")
    if mode == "rc":
        print("\n  When ready to cut the final: ./release.py final")
    # else: final's own Phase 10 already ran (or offered) open-dev.


# ── main ──────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="hollywood release pipeline",
        epilog="Modes: rc (default), final, open-dev, salsa-ci",
    )
    parser.add_argument(
        "mode", nargs="?",
        choices=["rc", "final", "open-dev", "salsa-ci"],
        default="rc",
    )
    parser.add_argument("--interactive", "-i", action="store_true", default=False)
    parser.add_argument(
        "--start-from", choices=_PHASE_ORDER, default=None,
        help="Resume a `final` run from this phase (e.g. after it died or "
             "you aborted a confirm), reusing the existing "
             "/tmp/hollywood-release-<ver> output dir instead of rebuilding "
             "and re-wiping everything before it. final only.",
    )
    args = parser.parse_args()
    mode = args.mode
    start_from = args.start_from
    if start_from and mode != "final":
        die("--start-from only applies to `final` (rc rebuilds are cheap "
            "and idempotent; there's nothing to resume there).")

    global _interactive
    _interactive = args.interactive

    if mode == "open-dev":
        identity = load_identity()
        open_dev(identity)
        return

    if mode == "salsa-ci":
        run_salsa_ci()
        return

    banner(f"hollywood release pipeline — {mode.upper()}"
           + (f"  [resuming from phase {start_from}]" if start_from else ""))

    identity = load_identity()
    check_salsa_sync(mode)
    check_tools(mode)
    check_clean()
    prewarm_gpg(identity)
    v = determine_versions(mode, resume=(start_from is not None))

    if should_run("3", start_from):
        # Phases 3 + 3b run in parallel (both are Docker, independent)
        run_parallel([
            ("smoke test",  run_smoke_test),
            ("salsa CI",    run_salsa_ci),
        ], log_dir=v["outdir"] / "logs")

    if should_run("4", start_from):
        # PPA builds (per-series parallelism handled inside)
        build_ppa_packages(v, identity)

    if should_run("5", start_from):
        # Debian source build
        build_debian_source(v, identity)

    if mode == "final":
        if should_run("6", start_from):
            create_github_release(v, identity)
        if should_run("7", start_from):
            sign_and_upload(v, identity)
        if should_run("8", start_from):
            push_salsa(v)
        if should_run("9", start_from):
            chainguard_reminder(v)

        # A final release leaves debian/changelog's top entry pinned at the
        # version that was just shipped. Any commit made after this point
        # with nothing bumped first has no home — it just piles onto the
        # already-released entry, same failure mode byobu's release.py
        # guards against in its own Phase 10 (and the exact thing
        # _OPEN_DEV_MSG_RE/commits_since_last_release in petname's
        # release.py were built to catch after it happened for real there).
        # Closing the loop here means the next cycle always has a home from
        # the moment this one's process exits.
        section("Phase 10: Open next development cycle")
        if confirm(
            f"Final release {v['base_ver']} is complete. Run open-dev now "
            f"to bump debian/changelog to the next version and open a "
            f"fresh UNRELEASED heading, so post-release commits don't "
            f"accumulate under the {v['base_ver']} label again?",
            skippable=True,
        ):
            open_dev(identity)

    print_summary(v, mode)


if __name__ == "__main__":
    main()
